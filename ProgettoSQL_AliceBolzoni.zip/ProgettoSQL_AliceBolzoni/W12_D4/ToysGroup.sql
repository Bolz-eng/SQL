create database ToysGroup ;

use ToysGroup ;
-- Creazione della tabella per l'entità Product
CREATE TABLE Products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(30) NOT NULL,
    product_price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL
);

-- Creazione della tabella per l'entità Region
CREATE TABLE Regions (
    region_id VARCHAR(30) PRIMARY KEY,
    region_name VARCHAR(30) NOT NULL,
    parent_region_id VARCHAR(30),
    state VARCHAR(50) NOT NULL
);

-- Creazione della tabella per l'entità Sales
CREATE TABLE Sales (
    sales_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    region_id VARCHAR(30) NOT NULL,
    sales_date DATE NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    amount INT,
    FOREIGN KEY (product_id) REFERENCES Products(product_id),
    FOREIGN KEY (region_id) REFERENCES Regions(region_id)
);



-- Inserisci dati nella tabella Products
INSERT INTO Products (product_id, product_name, product_price, category) VALUES
(1, 'Pictonary', 40, 'BoardGame'),
(2, 'Risiko', 45, 'BoardGame'),
(3, 'Monopoli', 30, 'BoardGame'),
(4, 'Twister', 25, 'BoardGame'),
(5, 'Microscopio', 40, 'Stem'),
(6, 'Labirinto', 30, 'Stem'),
(7, '3D World', 29, 'Puzzle'),
(8, 'Ravensburg La notte stellata', 24, 'Puzzle'),
(9, 'Fortnite', 25, 'VideoGame'),
(10, 'Call of Duty', 20, 'VideoGame'),
(11, 'Libro di stoffa', 13, 'Prima infanzia'),
(12, 'Sonaglio', 10, 'Prima infanzia'),
(13, 'Giostrina', 25, 'Prima infanzia');

-- Inserisci dati nella tabella Regions
INSERT INTO Regions (region_id, region_name, parent_region_id, state) VALUES
('WestEuro', 'WestEurope', null, 'European'),
('FranEuro', 'France', 'FranEuro', 'European'),
('GermEuro', 'Germany', 'GermEuro', 'European'),
('SoutEuro', 'SouthEurope', null, 'European'),
('ItalEuro', 'Italy', 'ItalEuro', 'European'),
('GreeEuro', 'Greece', 'GreeEuro', 'European'),
('SpaiEuro', 'Spain', 'SpaiEuro', 'European'),
('NethEuro', 'Netherland', 'NethEuro', 'European'),
('PortEuro', 'Portugal', 'PortEuro', 'European'),
('BelgEuro', 'Belgium', 'BelgEuro', 'European'),
('AustEuro', 'Austria', 'AustEuro', 'European'),
('SwisEuro', 'Swiss', 'SwisEuro', 'European'),
('UtahUnit', 'Utah', null, 'United States'),
('AndoEuro', 'Andorra', 'AndoEuro', 'European');

-- Inserisci dati nella tabella Sales
INSERT INTO sales (sales_id, product_id, region_id, sales_date, price, amount)
VALUES
(1259, 3, 'WestEuro', '2023-04-29', 5, 30),
(1260, 4, 'FranEuro', '2022-04-30', 1, 25),
(1261, 1, 'FranEuro', '2021-05-01', 1, 40),
(1262, 1, 'GermEuro', '2023-05-02', 2, 40),
(1263, 8, 'SoutEuro', '2020-05-03', 1, 24),
(1264, 1, 'ItalEuro', '2019-05-04', 1, 40),
(1265, 7, 'ItalEuro', '2018-05-05', 3, 29),
(1266, 9, 'GreeEuro', '2020-05-06', 1, 25),
(1267, 13, 'SpaiEuro', '2022-05-07', 2, 25),
(1268, 13, 'NethEuro', '2021-05-08', 1, 25),
(1269, 6, 'UtahUnit', '2021-05-09', 3, 30),
(1270, 4, 'WestEuro', '2019-05-10', 4, 25),
(1271, 9, 'ItalEuro', '2022-05-11', 2, 25),
(1272, 6, 'GreeEuro', '2020-05-12', 3, 30),
(1273, 10, 'SpaiEuro', '2020-05-13', 5, 20),
(1274, 1, 'NethEuro', '2022-05-14', 2, 40),
(1275, 4, 'GreeEuro', '2019-05-15', 4, 25),
(1276, 2, 'SpaiEuro', '2023-05-16', 1, 45),
(1277, 11, 'BelgEuro', '2021-05-17', 4, 13),
(1278, 6, 'AustEuro', '2018-05-18', 5, 30),
(1279, 13, 'SwisEuro', '2018-05-19', 3, 10),
(1280, 7, 'AndoEuro', '2022-05-20', 1, 29),
(1281, 10, 'SoutEuro', '2021-05-21', 2, 20),
(1282, 8, 'ItalEuro', '2023-05-22', 2, 24),
(1283, 1, 'BelgEuro', '2023-05-23', 3, 40),
(1284, 2, 'UtahUnit', '2020-05-24', 1, 45),
(1285, 7, 'NethEuro', '2024-01-25', 4, 29),
(1286, 11, 'WestEuro', '2023-05-26', 1, 13),
(1287, 6, 'FranEuro', '2018-05-27', 2, 30),
(1288, 4, 'UtahUnit', '2019-05-28', 2, 25);




-- Verificare che i campi definiti come PK siano univoci. 
-- Se i risultati del mio codice danno zero risultati allora i PK sono univoci.

-- Verifica chiave primaria univoca nella tabella Products
SELECT product_id, COUNT(*)
FROM Products
GROUP BY product_id
HAVING COUNT(*) > 1;

-- Verifica chiave primaria univoca nella tabella Regions
SELECT region_id, COUNT(*)
FROM Regions
GROUP BY region_id
HAVING COUNT(*) > 1;

-- Verifica chiave primaria univoca nella tabella Sales
SELECT sales_id, COUNT(*)
FROM Sales
GROUP BY sales_id
HAVING COUNT(*) > 1;


-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT
    P.product_id,
    P.product_name,
    YEAR(S.sales_date) AS sales_year,
    SUM(S.amount) AS total_revenue
FROM
    Products P
JOIN
    Sales S ON P.product_id = S.product_id
GROUP BY
    P.product_id, P.product_name, YEAR(S.sales_date)
ORDER BY
    P.product_id, YEAR(S.sales_date);


-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT 
    state,
    EXTRACT(YEAR FROM sales_date) AS sales_year,
    SUM(amount) AS total_sales
FROM Sales
JOIN Regions ON Sales.region_id = Regions.region_id
GROUP BY state, sales_year
ORDER BY sales_year, total_sales DESC;

-- qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT 
    category,
    SUM(amount) AS total_sales
FROM Sales
JOIN Products ON Sales.product_id = Products.product_id
GROUP BY category
ORDER BY total_sales DESC;


-- quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
SELECT Products.product_name
FROM Products
LEFT JOIN Sales ON Products.product_id = Sales.product_id
WHERE Sales.product_id IS NULL;

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 
    Products.product_name,
    MAX(Sales.sales_date) AS last_sale_date
FROM Products
LEFT JOIN Sales ON Products.product_id = Sales.product_id
GROUP BY Products.product_name;







